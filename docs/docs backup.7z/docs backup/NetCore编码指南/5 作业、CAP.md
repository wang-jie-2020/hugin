# 作业、CAP

将作业集中到`BackgroundJob`，见示例即可

将分布式事件集中到`Cap`，见示例即可

## 本机DEBUG调试

在debug调试时，通常希望本机实例总是与其他实例隔离，永远在本机命中断点。故调试时，在`Host.Shared.Global`中定义自己的唯一标识。

```csharp
    public static class Global
    {
        /*
         *  全局（本机）唯一标识
         *  注意：非DEBUG时，不得修改！！！
         */
#if DEBUG
        public const string Identifier = "_debug";	//_debug_{YourName}
#else
        public const string Identifier = "";
#endif
    }
```
## UnitOfWork

```csharp
[UnitOfWork]
public virtual async Task A(BookJobArgs args)

或
    
public async Task B(BookJobArgs args)
{
	using (var uow = UnitOfWorkManager.Begin())
	{
	}	
}
```

